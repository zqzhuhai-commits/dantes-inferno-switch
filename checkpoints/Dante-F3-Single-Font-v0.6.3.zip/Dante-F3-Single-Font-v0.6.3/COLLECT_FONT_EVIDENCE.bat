@echo off
cd /d "%~dp0"
py -3 tools\collect_font_evidence.py
if errorlevel 1 python tools\collect_font_evidence.py
pause
