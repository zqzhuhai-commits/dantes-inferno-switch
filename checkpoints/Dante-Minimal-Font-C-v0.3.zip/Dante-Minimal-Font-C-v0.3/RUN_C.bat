@echo off
cd /d "%~dp0"
py -3 patcher.py
if errorlevel 1 python patcher.py
pause
