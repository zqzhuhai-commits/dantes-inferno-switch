@echo off
cd /d "%~dp0"
py -3 launch_A.py
if errorlevel 1 python launch_A.py
pause
