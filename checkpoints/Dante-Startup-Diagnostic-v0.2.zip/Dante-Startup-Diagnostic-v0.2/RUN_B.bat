@echo off
cd /d "%~dp0"
py -3 launch_B.py
if errorlevel 1 python launch_B.py
pause
