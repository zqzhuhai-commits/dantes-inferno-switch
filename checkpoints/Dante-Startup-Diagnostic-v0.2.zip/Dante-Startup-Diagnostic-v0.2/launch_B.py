import patcher
patcher.MANIFEST_NAME="manifest-B.json"
patcher.gui()
