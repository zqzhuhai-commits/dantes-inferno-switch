import patcher
patcher.MANIFEST_NAME="manifest-A.json"
patcher.gui()
