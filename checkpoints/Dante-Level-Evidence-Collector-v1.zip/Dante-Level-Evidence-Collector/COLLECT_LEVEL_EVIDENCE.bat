@echo off
cd /d "%~dp0"
py -3 tools\collect_level_evidence.py
if errorlevel 1 python tools\collect_level_evidence.py
pause
